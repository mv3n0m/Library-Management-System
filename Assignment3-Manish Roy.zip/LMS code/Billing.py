from Catalog import Catalog

class Billing:
    def __init__(self, member, book, days):
        if days > 10:
            fine = (days - 10) * 5
            print(
                f"\nYou have exceeded the book issue period of 10 days!\nYou are eligible to be fined a sum of Rs.{fine} @ Rs.5/day.")
            confirmation = input(
                f"\nDo you wish to proceed with your account no. {member.acc_no} of {member.bank_name} bank?\n(y/n) => ")
            if confirmation in 'yY':
                print(
                    f"\nYou have been billed Rs.{fine} on {book.book} ISBN {book.isbn} issued for {days} days")
            elif confirmation in 'nN':
                print(
                    f"\nThe sum of Rs.{fine} will be added to your credit points.")
        print("\n\nYou can return the book to the counter!")
        Catalog.books_list[book.book].append(book)
        print(Catalog.books_list[book.book])

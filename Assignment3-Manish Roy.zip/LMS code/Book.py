from Catalog import Catalog
from BookItem import BookItem


class Book:
    def __init__(self, name, author, pub_date, pages):
        self.name = name
        self.author = author
        self.publish_date = pub_date
        self.pages = pages
        Catalog(self)

    def __repr__(self):
        return self.name + ' by ' + self.author

    def addBookItem(self, isbn, rack):
        Catalog.addBooks(self, BookItem(self, isbn, rack))

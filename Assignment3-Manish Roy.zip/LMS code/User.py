from Catalog import Catalog
from Book import Book
from Billing import Billing


class User:
    users_list = {}

    def __init__(self, name, location, age, aadhar_id):
        self.name = name
        self.location = location
        self.age = age
        self.aadhar_id = aadhar_id


class Librarian(User):
    def __init__(self, name, location, age, aadhar_id, emp_id):
        super().__init__(name, location, age, aadhar_id)
        self.emp_id = emp_id
        User.users_list[self] = "Librarian"

    def __repr__(self):
        return self.name + ' (' + self.emp_id + ')'

    def addBook(self):
        book_name = input("\n\nEnter book's name: ")
        author_name = input("Enter author's name: ")
        pub_date = input("Enter publish date: ")
        pages = input("Enter number of pages: ")
        book = Book(book_name, author_name, pub_date, pages)
        no_of_items = int(
            input(f"\nHow many {book_name} books do you wish to add?\n=> "))
        for i in range(no_of_items):
            print(f"Book {i+1}:")
            isbn = input("ISBN: ")
            rack = input("Rack: ")
            book.addBookItem(isbn, rack)

    def displayCatalog(self):
        Catalog.display()

    def removeBook(self):
        book_name = input("\n\nEnter the book name to remove: ")
        Catalog.removeBook(book_name)
        Catalog.display()


class Member(User):
    def __init__(self, name, location, age, aadhar_id, member_id, acc_no, bank_name):
        super().__init__(name, location, age, aadhar_id)
        self.member_id = member_id
        self.acc_no = acc_no
        self.bank_name = bank_name
        User.users_list[self] = []

    def __repr__(self):
        return self.name + ' (' + self.member_id + ')'

    def searchBook(self):
        key = int(input(
            "\n\nHow would you like to search the book for?\n1. By book's name\t2. By author's name\n=> "))
        keyword = input("Enter your search term\n=> ")
        result = Catalog.search(key, keyword)
        print("\nHere are your search results:")
        for item in result:
            if item:
                count = 1
                print(f"{count}. {item}")
                count += 1

    def issueBook(self, name, days=10):
        for book in Catalog.books_list:
            if name.strip().lower() == book.name.lower():
                book_issued = Catalog.books_list[book].pop(0)
        issued_books = User.users_list[self]
        if len(issued_books) <= 5:
            issued_books.append(book_issued)
        else:
            print("\nYou have already issued your quota of book i.e. 5 books.")
        print("\n\nYour books: ", issued_books)

    def returnBook(self):
        issued_books = User.users_list[self]
        print("\n\nYou have these books to return:")
        for item in issued_books:
            count = 1
            print(f"{count}. {item.book} \nISBN: {item.isbn}")
        choice = int(input("\nSelect the book to return\n=> "))
        days = int(input("No. of days you kept the book: "))
        Billing(self, issued_books[choice - 1], days)

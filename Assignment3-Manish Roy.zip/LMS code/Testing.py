from User import Librarian, Member

l = Librarian("Manish", "Jalandhar", 35, "Aadhar", "EMP101")
print(l)
l.addBook()
l.displayCatalog()

m = Member("Venom", 'Ludhiana', 18, "Aadhar", "MEM101", 132142141232312, "SBI")
print(m)
m.searchBook()
m.issueBook(input("Enter book title: "))
m.returnBook()

l.removeBook()
l.displayCatalog()

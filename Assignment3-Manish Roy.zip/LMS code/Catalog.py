
class Catalog:
    books_list = {}

    def __init__(self, book):
        Catalog.books_list[book] = []

    def addBooks(book, book_item):
        Catalog.books_list[book].append(book_item)

    def display():
        lis = Catalog.books_list
        if lis:
            for book in lis:
                print(book.name + ":\n\t    ISBN @ rack")
                for item in lis[book]:
                    print("\t=> ", item)

    def removeBook(book_name):
        for book in Catalog.books_list:
            if book_name.strip() == book.name:
                del Catalog.books_list[book]
                break

    def search(key, keyword):
        result = []
        for book in Catalog.books_list:
            if key == 1:
                temp = book.name
            elif key == 2:
                temp = book.author
            if keyword.strip().lower() in temp.lower():
                result.append(book)
        return result
